% No dogs purr.

%facts
dog(X).

%rules
doesnt_purr(X) :- dog(X).