% Any number is the successor of its predecessor.

%facts
succ(X).
pred(X).
equal(X,succ(pred(X))).