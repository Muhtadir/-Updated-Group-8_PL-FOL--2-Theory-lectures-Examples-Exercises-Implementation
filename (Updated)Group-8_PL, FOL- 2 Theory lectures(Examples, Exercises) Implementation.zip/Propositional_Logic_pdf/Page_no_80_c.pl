% 36 is a perfect square.

%facts
perfect_square(36).