% All dogs are faithful.

%facts
dog(X).

%rules
faithful(X) :- dog(X).