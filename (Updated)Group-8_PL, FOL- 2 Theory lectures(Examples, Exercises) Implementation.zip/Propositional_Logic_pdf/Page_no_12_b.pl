%If the roads are wet then it rains ???

%facts
road(wet).

%rules
rain(it) :- road(wet). 