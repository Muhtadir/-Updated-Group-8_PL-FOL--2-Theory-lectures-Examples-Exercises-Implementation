%If it rains then the roads are wet.

%facts
rain(it).

%rules
road(wet) :- rain(it).