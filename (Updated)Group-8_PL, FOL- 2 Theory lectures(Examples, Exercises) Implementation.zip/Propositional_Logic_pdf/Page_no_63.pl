% All birds cannot fly.

%facts
bird(X).

%rules
flightless(X) :- bird(X).