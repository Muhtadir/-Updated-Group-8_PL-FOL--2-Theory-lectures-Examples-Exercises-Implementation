% All men are mortal.

%facts
man(X).
mortal(X).

%rules
mortal(X) :- man(X).