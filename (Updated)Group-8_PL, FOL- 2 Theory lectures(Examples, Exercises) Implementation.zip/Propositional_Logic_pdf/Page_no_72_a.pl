% Everyone loves (all of) his/her brothers.

%facts
brother(X,Y).

%rules
love(X,Y) :- brother(X,Y).