% ABC is an equilateral triangle.

%facts
triangle(abc).

%rules
equilateral(abc) :- triangle(abc).