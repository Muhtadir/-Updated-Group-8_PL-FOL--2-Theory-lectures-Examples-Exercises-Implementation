% It is the month of July
% It rains
% If it is the month of July then it rains

%facts
month(july).
rain(it).

%rules
rain(it) :- month(july).