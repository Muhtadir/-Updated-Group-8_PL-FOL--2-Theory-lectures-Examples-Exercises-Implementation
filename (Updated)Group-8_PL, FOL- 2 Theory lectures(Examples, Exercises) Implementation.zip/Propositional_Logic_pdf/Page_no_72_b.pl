% Everyone loves his/her mother.

%facts
mother(X,Y)

%rules
loves(Y,X) :- mother(X,Y).