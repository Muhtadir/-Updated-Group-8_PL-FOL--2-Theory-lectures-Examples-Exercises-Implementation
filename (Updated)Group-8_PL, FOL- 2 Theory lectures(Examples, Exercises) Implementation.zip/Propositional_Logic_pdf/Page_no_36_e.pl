% Angle B is equal to angle C.

%facts
equal(b,c).