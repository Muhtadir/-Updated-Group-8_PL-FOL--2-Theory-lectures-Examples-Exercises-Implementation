% All dogs have four lags.

%facts
dog(X).

%rules
has_legs(X,4) :- dog(X).