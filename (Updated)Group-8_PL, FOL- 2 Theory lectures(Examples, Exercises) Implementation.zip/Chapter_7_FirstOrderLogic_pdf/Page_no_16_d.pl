% Clinton is not tall.

not(tall(clinton)).