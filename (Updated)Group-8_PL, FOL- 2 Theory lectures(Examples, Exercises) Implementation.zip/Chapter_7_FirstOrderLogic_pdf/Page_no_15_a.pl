% Every gardener likes the sun.

%facts
gardener(X).

%rules
likes(X,sun) :- gardener(X).