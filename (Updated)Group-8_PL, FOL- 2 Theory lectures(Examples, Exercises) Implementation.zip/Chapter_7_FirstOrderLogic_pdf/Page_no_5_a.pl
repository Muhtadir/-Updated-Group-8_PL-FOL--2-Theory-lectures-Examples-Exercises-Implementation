% One plus two equals three.

%facts
3 is 1+2.